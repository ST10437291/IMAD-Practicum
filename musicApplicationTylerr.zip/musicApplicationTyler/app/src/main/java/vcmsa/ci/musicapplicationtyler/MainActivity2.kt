package vcmsa.ci.musicapplicationtyler

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class QuestionActivity : AppCompatActivity() {



    val btn1 = findViewById<Button>(R.id.btn1)
    startButton1.setOnClickListener {
        val btn2 = findViewById<Button>(R.id.btn2)
        btn2.setOnClickListener {
            val TextView = findViewById<TextView>(R.id.RatingTxt)
            TextView.setOnClickListener {
                val SeekBar= findViewById<SeekBar>(R.id.seekBar)
                SeekBar.setOnClickListener {
                }
            }





//W3Schools. (2024). W3Schools Online Web Tutorials. [online] Available at: https://www.w3schools.com/ [Accessed 16 May 2025]
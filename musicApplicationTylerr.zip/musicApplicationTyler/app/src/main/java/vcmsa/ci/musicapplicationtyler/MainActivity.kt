package vcmsa.ci.musicapplicationtyler

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d("MainActivity", "App Started")

        val startButton1 = findViewById<Button>(R.id.btnStart)
        startButton1.setOnClickListener {
            val startButton2 = findViewById<Button>(R.id.btnStart)
            startButton2.setOnClickListener {
                val startButton3 = findViewById<Button>(R.id.btnStart)
                startButton3.setOnClickListener {
                    val startButton4 = findViewById<Button>(R.id.btnStart)
                    startButton4.setOnClickListener {
                    }
                }
                val imageView: ImageView = findViewById(R.id.myImageView)
                Log.d("MainActivity", "Start Button Clicked")
                val intent = Intent(this, QuestionActivity::class.java)
                startActivity(intent)
            }
        }
    }
}



